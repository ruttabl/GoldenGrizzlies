﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            //dataGridView1.Rows.Add("264918", "Fusion", "SE", "2019", "Black", "$18,999", "YES");
            //dataGridView1.Rows.Add("724825", "F-150", "XLT", "2021", "Orange", "$29,999", "NO");
            //dataGridView1.Rows.Add("917903", "Explorer", "ST", "2020", "White", "$20,999", "YES");
            //dataGridView2.Rows.Add("023895", "Malibu", "L", "2017", "Red", "$12,999", "YES");
            //dataGridView2.Rows.Add("237723", "Cruze", "LS", "2014", "Grey", "$8,999", "YES");
            //dataGridView2.Rows.Add("019583", "Malibu", "RS", "2021", "Black", "$25,999", "NO");
            //dataGridView3.Rows.Add("953495", "Cherokee", "L", "2019", "Black", "$16,999", "YES");
            //dataGridView3.Rows.Add("257002", "Grand Cherokee", "Trackhawk", "2018", "White", "$24,999", "YES");
            //dataGridView3.Rows.Add("195397", "Grand Wagoneer", "Series III", "2022", "Black", "$119,999", "YES");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //dataGridView1.Rows.Add("yep", "nope", "hmm", "aye");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.projectDataSet.customer);
            // TODO: This line of code loads data into the 'projectDataSet.sale' table. You can move, or remove it, as needed.
            this.saleTableAdapter.Fill(this.projectDataSet.sale);


        }

        private void advancedDataGridView1_SortStringChanged(object sender, EventArgs e)
        {
            this.saleBindingSource.Sort = this.advancedDataGridView1.SortString;
        }

        private void advancedDataGridView1_FilterStringChanged(object sender, EventArgs e)
        {
            this.saleBindingSource.Filter = this.advancedDataGridView1.FilterString;
        }

        private void advancedDataGridView2_SortStringChanged(object sender, EventArgs e)
        {
            this.saleBindingSource.Sort = this.advancedDataGridView2.SortString;
        }

        private void advancedDataGridView2_FilterStringChanged(object sender, EventArgs e)
        {
            this.customerBindingSource.Filter = this.advancedDataGridView2.FilterString;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void saleBindingSource_ListChanged(object sender, ListChangedEventArgs e)
        {
            label2.Text = string.Format("Number of Results: {0}", this.saleBindingSource.List.Count);
        }

        private void customerBindingSource_ListChanged(object sender, ListChangedEventArgs e)
        {
            label3.Text = string.Format("Number of Results: {0}", this.customerBindingSource.List.Count);
        }
    }
}
