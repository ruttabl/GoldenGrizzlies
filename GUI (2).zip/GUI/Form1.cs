﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()

        {
            InitializeComponent();
            //dataGridView1.Rows.Add("06/11/21", "4:31pm", "Chris Evans", "cevans@gmail.com", "248-523-6236", "5UXFE83507LZ40758", "$28,999", "David");
            //dataGridView1.Rows.Add("02/04/21", "1:56pm", "Elizabeth Olson", "eolson@gmail.com", "248-624-7247", "WBA3A5C57CF256651", "$23,999", "Trisha");
            //dataGridView1.Rows.Add("07/17/21", "3:23pm", "Jeremy Renner", "jrenner@gmail.com", "248-973-9245", "1HGCM66554A033052", "$15,999", "David");
            //dataGridView1.Rows.Add("11/25/21", "11:37am", "Chris Hemsworth", "chemsworth@gmail.com", "248-268-9573", "1GTEK19RXVE536195", "$8,999", "Joe");
            //dataGridView1.Rows.Add("05/28/21", "2:42pm", "Robert Downey Jr.", "rdj@gmail.com", "248-773-1367", "WBACD432XWAV64423", "$17,999", "Emily");
            string server = "localhost";
            string database = "project";
            string username = "root";
            string password = "Rachael11";
            string constring = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + username + ";" + "PASSWORD=" + password + ";";
            MySqlConnection conn = new MySqlConnection(constring);
            conn.Open();
            string query = "SELECT DISTINCT CAR_ID, CAR_COLOR, CAR_STARTING_PRICE, CAR_HORSEPOWER, CAR_MPG, MODEL_NAME, TRIM_NAME, MAN_MAKE_NAME FROM CAR JOIN MODEL ON CAR_ID = MODEL_CAR_ID JOIN Manufacturer ON CAR_ID = MAN_CAR_ID JOIN TRIM ON CAR_ID = CAR_CAR_ID;";
            string query1 = "SELECT Sale_ID, Sale_Date, Sale_Employee_ID, Sale_Customer_ID, Sale_Sale_Amount, Sale_Closed, Sale_Car_ID FROM sale;";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataReader reader = cmd.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1.DataSource = table;
            conn.Close();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int n = dataGridView1.Rows.Add();
            //dataGridView1.Rows[n].Cells[0].Value = textBox2.Text;
            //dataGridView1.Rows[n].Cells[1].Value = textBox3.Text;
            //dataGridView1.Rows[n].Cells[2].Value = textBox4.Text;
            //dataGridView1.Rows[n].Cells[3].Value = textBox5.Text;
            //dataGridView1.Rows[n].Cells[4].Value = textBox6.Text;
            //dataGridView1.Rows[n].Cells[5].Value = textBox7.Text;
            //dataGridView1.Rows[n].Cells[6].Value = textBox8.Text;
            //dataGridView1.Rows[n].Cells[7].Value = textBox9.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet.sale' table. You can move, or remove it, as needed.
            this.saleTableAdapter.Fill(this.projectDataSet.sale);
            // TODO: This line of code loads data into the 'projectDataSet.employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.projectDataSet.employee);
            // TODO: This line of code loads data into the 'projectDataSet.car' table. You can move, or remove it, as needed.
            //this.carTableAdapter1.Fill(this.projectDataSet.car);
            // TODO: This line of code loads data into the 'finalProjectDataSet.car' table. You can move, or remove it, as needed.
            this.carTableAdapter.Fill(this.finalProjectDataSet.car);
            // TODO: This line of code loads data into the 'projectDataSet.car' table. You can move, or remove it, as needed.
           // this.carTableAdapter.Fill(this.finalProjectDataSet.car);
            // TODO: This line of code loads data into the 'projectDataSet.customer' table. You can move, or remove it, as needed.
            //this.customerTableAdapter.Fill(this.projectDataSet.customer);

            // TODO: This line of code loads data into the 'projectDataSet.car' table. You can move, or remove it, as needed.
            //this.carTableAdapter.Fill(this.projectDataSet.car);
            // TODO: This line of code loads data into the 'projectDataSet.car' table. You can move, or remove it, as needed.
            //this.carTableAdapter.Fill(this.projectDataSet.car);
            //dataGridView1.DataSource = GetEmployeesList();


        }

        //private DataTable GetEmployeesList()
        //{
        //    DataTable dtEmployees = new DataTable();


        //    return dtEmployees;
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
            this.Close();

        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //((DataTable)dataGridView1.DataSource).DefaultView.RowFilter = "FirstName = 'John'";
        }

        private void dataGridView1_SortStringChanged(object sender, EventArgs e)
        {
            this.carBindingSource.Sort = this.dataGridView1.SortString;
        }

        private void dataGridView1_FilterStringChanged(object sender, EventArgs e)
        {
            this.carBindingSource.Filter = this.dataGridView1.FilterString;
        }

        private void carBindingSource_ListChanged(object sender, ListChangedEventArgs e)
        {
            label10.Text = string.Format("Number of Results: {0}", this.carBindingSource.List.Count);
        }

        private void searchToolBar1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                label1.Hide();
            }
            else
                label1.Show();
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            //(dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("Man_Make_Name like '%" + textBox1.Text + "%'");
            
            if(radioButton1.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Convert(Car_ID, 'System.String') LIKE '" + textBox1.Text.ToString() + "%'";
            }
            if (radioButton2.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Car_MPG LIKE '%" + textBox1.Text.ToString() + "%'";
            }
            if (radioButton3.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Model_Name like '%" + textBox1.Text + "%'";
            }
            if (radioButton4.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Car_Color like '%" + textBox1.Text + "%'";
            }
            if (radioButton5.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Trim_Name like '%" + textBox1.Text + "%'";
            }
            if (radioButton6.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Car_Starting_Price like '%" + textBox1.Text.ToString() + "%'";
            }
            if (radioButton7.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Man_Make_Name like '%" + textBox1.Text + "%'";
            }
            if (radioButton8.Checked)
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "Car_Horsepower like '%" + textBox1.Text.ToString() + "%'";
            }


        }

        public void button2_Click(object sender, EventArgs e)
        {
            string server = "localhost";
            string database = "project";
            string username = "root";
            string password = "Rachael11";
            string connstring = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + username + ";" + "PASSWORD=" + password + ";";
            MySqlConnection connn = new MySqlConnection(connstring);
            connn.Open();
            string query1 = "INSERT INTO CAR VALUES(23, 'YELLOW', 25252, 1, 0, '2021', 200, 16);";
            //string query1 = "SELECT Sale_ID, Sale_Date, Sale_Employee_ID, Sale_Customer_ID, Sale_Sale_Amount, Sale_Closed, Sale_Car_ID FROM sale;";
            MySqlCommand cmd = new MySqlCommand(query1, connn);
            MySqlDataReader reader = cmd.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1.DataSource = table;
            connn.Close();
        }

    }
}
